#!/bin/bash
# Installs the gateway as a self-updatable systemd service. Run as root from an unpacked
# release folder (the one holding NeoCortecGateway and gw.cfg), or pass that folder as $1.
#   sudo ./install.sh [release-folder]
set -eu

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC="${1:-$PWD}"
ROOT="${NEO_GATEWAY_ROOT:-/opt/neocortec/gateway}"
CONFIG_DIR="${NEO_CONFIG_DIR:-/etc/neocortec}"
DATA_DIR="${NEO_DATA_DIR:-/var/lib/neocortec}"
UNIT_DIR="${NEO_UNIT_DIR:-/etc/systemd/system}"
SYSTEMCTL="${SYSTEMCTL:-systemctl}"
# Where the old layout kept things; overridable so the installer can be tested without root.
LEGACY_ROOT="${NEO_LEGACY_ROOT:-}"          # the old service ran in /
LEGACY_SYSTEMD="${NEO_LEGACY_SYSTEMD:-/lib/systemd}"
KILLALL="${KILLALL:-killall}"

die() {
	echo "install: $*" >&2
	exit 1
}

[ "$(id -u)" -eq 0 ] || [ -n "${NEO_ALLOW_NON_ROOT:-}" ] || die "run as root (sudo ./install.sh)"
[ -f "$SRC/NeoCortecGateway" ] || die "NeoCortecGateway not found in $SRC"
chmod 755 "$SRC/NeoCortecGateway"

# Output is "NeoCortecGateway <version> <platform>"
VERSION="$("$SRC/NeoCortecGateway" --version | awk '{print $2}')"
[[ $VERSION =~ ^[0-9]+(\.[0-9]+)*$ ]] || die "cannot read the version from NeoCortecGateway --version"
echo "Installing NeoCortecGateway $VERSION into $ROOT"

# --- stop a running gateway (old style or service) ---
"$SYSTEMCTL" stop NeoGW.service 2> /dev/null || true
"$SYSTEMCTL" disable NeoGW.service 2> /dev/null || true
"$KILLALL" -s INT NeoCortecGateway 2> /dev/null || true

# --- layout ---
mkdir -p "$ROOT/releases" "$ROOT/incoming" "$ROOT/backup" "$CONFIG_DIR" "$DATA_DIR"

# --- configuration: from the old layout, else keep what exists, else the one next to the binary ---
if [ -f "$LEGACY_SYSTEMD/gw.cfg" ] && [ ! -f "$CONFIG_DIR/gw.cfg" ]; then
	mv "$LEGACY_SYSTEMD/gw.cfg" "$CONFIG_DIR/gw.cfg"
elif [ ! -f "$CONFIG_DIR/gw.cfg" ] && [ -f "$SRC/gw.cfg" ]; then
	cp "$SRC/gw.cfg" "$CONFIG_DIR/gw.cfg"
fi
[ -f "$CONFIG_DIR/gw.cfg" ] || die "no gw.cfg found: put one next to NeoCortecGateway, or in $CONFIG_DIR"

# The old service ran in / so relative paths pointed there. Now they point into DATA_DIR.
move_data() { # path relative to the old working directory
	local f="$1" suffix
	for suffix in "" "-wal" "-shm"; do
		if [ -f "$LEGACY_ROOT/$f$suffix" ] && [ ! -e "$DATA_DIR/$f$suffix" ]; then
			mkdir -p "$(dirname "$DATA_DIR/$f")"
			mv "$LEGACY_ROOT/$f$suffix" "$DATA_DIR/$f$suffix"
			echo "Moved $LEGACY_ROOT/$f$suffix to $DATA_DIR/"
		fi
	done
}

# Move the file a relative gw.cfg key points at (absolute paths stay where they are).
move_relative_cfg_file() { # key
	local value
	value="$(sed -n "s/^[[:space:]]*$1[[:space:]]*=[[:space:]]*//p" "$CONFIG_DIR/gw.cfg" | tail -n 1 | tr -d '\r' | sed 's/[[:space:]]*$//')"
	case "$value" in
		'' | /*) ;;
		*)
			value="${value#./}"
			case "$value" in
				*..*) ;;
				*) move_data "$value" ;;
			esac
			;;
	esac
}

move_data gateway-settings.json
move_data floorplan-config.json # legacy settings file, still read by the gateway
move_relative_cfg_file historyDb
move_relative_cfg_file settingsConfig

# --- release ---
DEST="$ROOT/releases/$VERSION"
CURRENT_TARGET="$(readlink "$ROOT/current" 2> /dev/null || true)"
if [ "$CURRENT_TARGET" != "releases/$VERSION" ] && [ -d "$DEST" ]; then
	rm -r "$DEST"
fi
mkdir -p "$DEST/helper"
# install_file <src> <dest>: copy to a temporary name, then rename over the destination, so
# a running helper or gateway keeps its old file instead of seeing it rewritten in place.
install_file() {
	cp "$1" "$2.tmp.$$"
	chmod 755 "$2.tmp.$$"
	mv -f "$2.tmp.$$" "$2"
}
install_file "$SRC/NeoCortecGateway" "$DEST/NeoCortecGateway"
install_file "$HERE/neo-gateway-update.sh" "$DEST/helper/neo-gateway-update.sh"

# `current`, atomically (GNU mv needs -T to replace a link to a directory, BSD mv needs -h)
ln -sfn "releases/$VERSION" "$ROOT/current.new"
mv -Tf "$ROOT/current.new" "$ROOT/current" 2> /dev/null || mv -hf "$ROOT/current.new" "$ROOT/current"

# --- units ---
# The old layout kept the unit and binary under /lib/systemd; remove them so they cannot shadow the new ones.
rm -f "$LEGACY_SYSTEMD/system/NeoGW.service" "$LEGACY_SYSTEMD/NeoCortecGateway"
mkdir -p "$UNIT_DIR"
cp "$HERE/NeoGW.service" "$HERE/neo-gateway-update.service" "$UNIT_DIR/"

echo "service" > "$ROOT/installed-by-service"

"$SYSTEMCTL" daemon-reload
"$SYSTEMCTL" enable NeoGW.service
# Enabled so systemd runs the helper at boot when an update was cut off by a power loss
# (the unit's ConditionPathExists skips it otherwise).
"$SYSTEMCTL" enable neo-gateway-update.service
"$SYSTEMCTL" start NeoGW.service
echo "NeoGW.service started. Config: $CONFIG_DIR/gw.cfg, data: $DATA_DIR"
