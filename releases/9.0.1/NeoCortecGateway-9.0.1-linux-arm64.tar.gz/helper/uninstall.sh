#!/bin/bash
# Removes the NeoCortec gateway service and its install folder. Asks before deleting
# configuration and data.
set -u

ROOT="${NEO_GATEWAY_ROOT:-/opt/neocortec/gateway}"
CONFIG_DIR="${NEO_CONFIG_DIR:-/etc/neocortec}"
DATA_DIR="${NEO_DATA_DIR:-/var/lib/neocortec}"
UNIT_DIR="${NEO_UNIT_DIR:-/etc/systemd/system}"
SYSTEMCTL="${SYSTEMCTL:-systemctl}"

if [ "$(id -u)" -ne 0 ] && [ -z "${NEO_ALLOW_NON_ROOT:-}" ]; then
	echo "uninstall: run as root (sudo ./uninstall.sh)" >&2
	exit 1
fi

"$SYSTEMCTL" stop neo-gateway-update.service NeoGW.service 2> /dev/null
"$SYSTEMCTL" disable NeoGW.service 2> /dev/null
"$SYSTEMCTL" disable neo-gateway-update.service 2> /dev/null
rm -f "$UNIT_DIR/NeoGW.service" "$UNIT_DIR/neo-gateway-update.service"
"$SYSTEMCTL" daemon-reload
rm -rf "$ROOT"
echo "Removed the services and $ROOT"

read -r -p "Also delete $CONFIG_DIR and $DATA_DIR (config, settings, history)? [y/N] " answer
case "$answer" in
	y | Y | yes | YES)
		rm -rf "$CONFIG_DIR" "$DATA_DIR"
		echo "Removed $CONFIG_DIR and $DATA_DIR"
		;;
	*) echo "Kept $CONFIG_DIR and $DATA_DIR" ;;
esac
