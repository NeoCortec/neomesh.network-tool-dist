#!/bin/bash
# NeoCortec gateway update helper (Linux). Runs as root from neo-gateway-update.service,
# always from the OLD release. Switches `current`, restarts the gateway, waits for the
# `healthy` marker and rolls back when it does not appear. See adr/5-gateway-self-update.md.
#
# Deliberately no `set -e`: a failing restart or link command must lead to a rollback,
# not to an aborted script with a half-switched link. Every step checks its own result.
set -u

ROOT="${NEO_GATEWAY_ROOT:-/opt/neocortec/gateway}"
CONFIG_DIR="${NEO_CONFIG_DIR:-/etc/neocortec}"
DATA_DIR="${NEO_DATA_DIR:-/var/lib/neocortec}"
HEALTH_TIMEOUT="${NEO_HEALTH_TIMEOUT:-90}"
SYSTEMCTL="${SYSTEMCTL:-systemctl}"
SERVICE="NeoGW.service"

case "$HEALTH_TIMEOUT" in
	'' | *[!0-9]*) HEALTH_TIMEOUT=90 ;;
esac

PENDING="$ROOT/pending.env"
HEALTHY="$ROOT/healthy"
RESULT_FILE="$ROOT/last-update.json"
LOG_FILE="$ROOT/helper.log"
CONFIG_FILES=("$CONFIG_DIR/gw.cfg" "$DATA_DIR/gateway-settings.json")

MODE=""
REQUEST_ID=""
FROM_VERSION=""
TO_VERSION=""

log() {
	local line
	line="$(date '+%Y-%m-%dT%H:%M:%S%z') $*"
	echo "$line" >> "$LOG_FILE" 2> /dev/null
	echo "$line"
}

# Trim the log so it cannot grow without bound.
trim_log() {
	if [ -f "$LOG_FILE" ] && [ "$(wc -l < "$LOG_FILE")" -gt 1000 ]; then
		tail -n 500 "$LOG_FILE" > "$LOG_FILE.tmp" && mv -f "$LOG_FILE.tmp" "$LOG_FILE"
	fi
}

# ---- JSON output -----------------------------------------------------------------

json_escape() {
	local s="$1" out="" ch code i
	s="${s//\\/\\\\}"
	s="${s//\"/\\\"}"
	s="${s//$'\t'/\\t}"
	s="${s//$'\r'/\\r}"
	s="${s//$'\n'/\\n}"
	if [[ $s =~ [[:cntrl:]] ]]; then
		local LC_ALL=C
		for ((i = 0; i < ${#s}; i++)); do
			ch="${s:i:1}"
			printf -v code '%d' "'$ch"
			if [ "$code" -lt 32 ] && [ "$code" -gt 0 ]; then
				printf -v ch '\\u%04x' "$code"
			fi
			out+="$ch"
		done
		s="$out"
	fi
	printf '%s' "$s"
}

# write_result <result> <errorCode> <errorMessage>
write_result() {
	local tmp="$RESULT_FILE.tmp" line first=1
	{
		printf '{\n'
		printf '  "requestId": "%s",\n' "$(json_escape "$REQUEST_ID")"
		printf '  "result": "%s",\n' "$(json_escape "$1")"
		printf '  "fromVersion": "%s",\n' "$(json_escape "$FROM_VERSION")"
		printf '  "toVersion": "%s",\n' "$(json_escape "$TO_VERSION")"
		printf '  "errorCode": "%s",\n' "$(json_escape "$2")"
		printf '  "errorMessage": "%s",\n' "$(json_escape "$3")"
		printf '  "log": ['
		if [ -f "$LOG_FILE" ]; then
			while IFS= read -r line || [ -n "$line" ]; do
				if [ "$first" -eq 1 ]; then printf '\n'; else printf ',\n'; fi
				first=0
				printf '    "%s"' "$(json_escape "$line")"
			done < <(tail -n 30 "$LOG_FILE")
		fi
		if [ "$first" -eq 0 ]; then printf '\n  '; fi
		printf ']\n}\n'
	} > "$tmp" && mv -f "$tmp" "$RESULT_FILE"
	log "result=$1 errorCode=$2"
}

# ---- Symlink handling ------------------------------------------------------------

# GNU mv needs -T to replace a symlink to a directory; BSD mv needs -h (ledger ruling R2).
MV_SWAP=""
detect_mv_swap() {
	local probe="$ROOT/.mvprobe.$$"
	mkdir -p "$probe/d" && ln -s d "$probe/a" && ln -s d "$probe/b"
	if mv -Tf "$probe/a" "$probe/b" 2> /dev/null && [ ! -e "$probe/a" ]; then
		MV_SWAP="-Tf"
	else
		MV_SWAP="-hf"
	fi
	rm -r "$probe" 2> /dev/null
}

# set_link <name> <target>: atomically point $ROOT/<name> at <target>
set_link() {
	local name="$1" target="$2"
	ln -sfn "$target" "$ROOT/$name.new" || return 1
	# shellcheck disable=SC2086 # MV_SWAP is a single option word
	mv $MV_SWAP "$ROOT/$name.new" "$ROOT/$name" || {
		rm -f "$ROOT/$name.new"
		return 1
	}
}

# link_target <name>: the stored (possibly relative) target, empty if no such link
link_target() { readlink "$ROOT/$1" 2> /dev/null || true; }

# abs_path <stored target>
abs_path() {
	case "$1" in
		/*) printf '%s' "$1" ;;
		*) printf '%s/%s' "$ROOT" "$1" ;;
	esac
}

has_binary() { [ -f "$(abs_path "$1")/NeoCortecGateway" ] && [ -x "$(abs_path "$1")/NeoCortecGateway" ]; }

# ---- Steps -----------------------------------------------------------------------

valid_version() {
	[[ $1 =~ ^[0-9]+(\.[0-9]+)*$ ]]
}

# Strict line-by-line KEY=value read. Never sourced or evaluated; values stay percent-encoded.
read_pending() {
	local line key value
	[ -f "$PENDING" ] || return 1
	while IFS= read -r line || [ -n "$line" ]; do
		case "$line" in
			*=*) ;;
			*) continue ;;
		esac
		key="${line%%=*}"
		value="${line#*=}"
		case "$key" in
			MODE) MODE="$value" ;;
			REQUEST_ID) REQUEST_ID="$value" ;;
			FROM_VERSION) FROM_VERSION="$value" ;;
			TO_VERSION) TO_VERSION="$value" ;;
			*) ;; # ISSUED_BY, SERIAL_WAS_OK and unknown keys are ignored
		esac
	done < "$PENDING"
}

# service_cmd <stop|start>: run systemctl, log its output, return its exit status
service_cmd() {
	local out rc
	out="$("$SYSTEMCTL" "$1" "$SERVICE" 2>&1)"
	rc=$?
	[ -n "$out" ] && log "systemctl: $out"
	[ "$rc" -eq 0 ] || log "systemctl $1 $SERVICE failed (exit $rc)"
	return "$rc"
}

# Stop, clear the healthy marker, start. Stopping first means the old gateway cannot
# recreate `healthy`, and a running gateway cannot write config while we restore it.
stop_service() { service_cmd stop; }
start_service() {
	rm -f "$HEALTHY"
	service_cmd start
}

# norm_version <version>: numeric form without leading zeros or trailing ".0" parts, so
# "5.3", "5.3.0" and "05.3" compare equal (like CompareVersions in the gateway).
norm_version() {
	local IFS=. part parts=() out=() n
	read -r -a parts <<< "$1"
	for part in "${parts[@]}"; do
		part="${part#"${part%%[!0]*}"}"
		out+=("${part:-0}")
	done
	n=${#out[@]}
	while [ "$n" -gt 1 ] && [ "${out[n - 1]}" = 0 ]; do
		n=$((n - 1))
	done
	printf '%s' "${out[*]:0:n}"
}

# The marker counts only when the gateway that wrote it reports TO_VERSION. An old gateway
# that kept running (failed stop) writes its own version and cannot fake a success.
marker_matches() {
	local v
	[ -f "$HEALTHY" ] || return 1
	IFS= read -r v < "$HEALTHY" || [ -n "$v" ] || return 1
	valid_version "$v" && [ "$(norm_version "$v")" = "$(norm_version "$TO_VERSION")" ]
}

wait_healthy() {
	local waited=0
	while [ "$waited" -le "$HEALTH_TIMEOUT" ]; do
		marker_matches && return 0
		[ "$waited" -lt "$HEALTH_TIMEOUT" ] && sleep 1
		waited=$((waited + 1))
	done
	return 1
}

backup_config() {
	local dest="$ROOT/backup/$FROM_VERSION" f
	mkdir -p "$dest" || return 1
	for f in "${CONFIG_FILES[@]}"; do
		if [ -f "$f" ]; then
			cp -p "$f" "$dest/" || return 1
			log "backed up $f"
		else
			log "no $f to back up"
		fi
	done
}

restore_config() {
	local src="$ROOT/backup/$FROM_VERSION" f
	for f in "${CONFIG_FILES[@]}"; do
		if [ -f "$src/$(basename "$f")" ]; then
			if cp -p "$src/$(basename "$f")" "$f"; then log "restored $f"; else log "could not restore $f"; fi
		fi
	done
}

# Keep only the releases `current` and `previous` point at. Skipped unless both
# links point into releases/, so a odd layout never loses data.
prune_releases() {
	local keep=() t d name
	for t in "$(link_target current)" "$(link_target previous)"; do
		[ -z "$t" ] && continue
		case "$t" in
			releases/* | "$ROOT"/releases/*) keep+=("$(basename "$t")") ;;
			*)
				log "not pruning: link target $t is outside releases/"
				return 0
				;;
		esac
	done
	[ "${#keep[@]}" -gt 0 ] || return 0
	for d in "$ROOT"/releases/*; do
		if [ ! -d "$d" ] || [ -L "$d" ]; then continue; fi
		name="$(basename "$d")"
		case " ${keep[*]} " in
			*" $name "*) ;;
			*)
				log "removing old release $name"
				rm -r "$d"
				;;
		esac
	done
}

# Copy the gateway's last journal lines into the log (and so into the status `log`),
# so the user sees why the new release failed. Silently skipped without journalctl.
log_journal() {
	local line
	command -v journalctl > /dev/null 2>&1 || return 0
	while IFS= read -r line; do
		log "journal: $line"
	done < <(journalctl -u "$SERVICE" -n 15 --no-pager -o cat 2> /dev/null)
}

finish() { # remove the pending file, then prune when asked
	rm -f "$PENDING"
	log "pending.env removed"
	[ "${1:-}" = prune ] && prune_releases
	exit 0
}

fail_before_switch() { # code message
	log "refusing: $2"
	write_result failed "$1" "$2"
	finish
}

# True when link <name> points at releases/<version>.
link_is() {
	local t
	t="$(link_target "$1")"
	[ "$t" = "releases/$2" ] || [ "$t" = "$ROOT/releases/$2" ]
}

# Put both links back where the rollback target says (ROLL_CURRENT / ROLL_PREVIOUS).
restore_links() {
	set_link current "$ROLL_CURRENT" || log "could not restore current -> $ROLL_CURRENT"
	if [ -n "$ROLL_PREVIOUS" ]; then
		set_link previous "$ROLL_PREVIOUS" || log "could not restore previous -> $ROLL_PREVIOUS"
	else
		rm -f "$ROOT/previous"
	fi
}

# ---- Main ------------------------------------------------------------------------

trim_log
log "helper started (root=$ROOT, timeout=${HEALTH_TIMEOUT}s)"
detect_mv_swap

if ! read_pending; then
	fail_before_switch INVALID_PAYLOAD "pending.env missing or unreadable"
fi
log "request mode=$MODE from=$FROM_VERSION to=$TO_VERSION"

if [ "$MODE" != update ] && [ "$MODE" != revert ]; then
	fail_before_switch INVALID_PAYLOAD "MODE must be update or revert"
fi
if ! valid_version "$FROM_VERSION" || ! valid_version "$TO_VERSION"; then
	fail_before_switch INVALID_PAYLOAD "FROM_VERSION and TO_VERSION must be digits and dots"
fi

OLD_CURRENT="$(link_target current)"
OLD_PREVIOUS="$(link_target previous)"
if [ -z "$OLD_CURRENT" ]; then
	fail_before_switch SWITCH_FAILED "current is not a symlink"
fi

# Resume: the links already show the switch was done (power loss or reboot during the
# health wait), so skip backup and switching and go straight to the health wait.
RESUMING=0
if [ "$MODE" = update ] && link_is current "$TO_VERSION" && link_is previous "$FROM_VERSION"; then
	RESUMING=1
	ROLL_CURRENT="$OLD_PREVIOUS"
	ROLL_PREVIOUS="" # what previous pointed at before the update is no longer known
elif [ "$MODE" = revert ] && link_is current "$TO_VERSION"; then
	RESUMING=1
	# The revert moves current first, then previous. A power cut between the two leaves
	# previous on TO as well, so roll back to FROM by name, never to what previous says.
	ROLL_CURRENT="releases/$FROM_VERSION"
	ROLL_PREVIOUS="$OLD_CURRENT"
	if ! link_is previous "$FROM_VERSION"; then
		if set_link previous "releases/$FROM_VERSION"; then
			log "previous -> releases/$FROM_VERSION (second link move was interrupted)"
		else
			log "could not re-point previous -> releases/$FROM_VERSION"
		fi
	fi
fi

if [ "$RESUMING" -eq 1 ]; then
	log "links already switched, resuming at the health wait"
else
	ROLL_CURRENT="$OLD_CURRENT"
	ROLL_PREVIOUS="$OLD_PREVIOUS"

	if [ "$MODE" = update ]; then
		NEW_CURRENT="releases/$TO_VERSION"
		NEW_PREVIOUS="$OLD_CURRENT"
	else
		NEW_CURRENT="$OLD_PREVIOUS"
		NEW_PREVIOUS="$OLD_CURRENT"
	fi
	if [ -z "$NEW_CURRENT" ] || ! has_binary "$NEW_CURRENT"; then
		fail_before_switch BINARY_CHECK_FAILED "no executable NeoCortecGateway in ${NEW_CURRENT:-previous release}"
	fi

	if [ "$MODE" = update ]; then
		if ! backup_config; then
			fail_before_switch BACKUP_FAILED "could not back up config and settings"
		fi
	fi

	# Switch. At every moment both links point at a release that exists.
	switch_ok=1
	if [ "$MODE" = update ]; then
		set_link previous "$NEW_PREVIOUS" && set_link current "$NEW_CURRENT" || switch_ok=0
	else
		set_link current "$NEW_CURRENT" && set_link previous "$NEW_PREVIOUS" || switch_ok=0
	fi
	if [ "$switch_ok" -ne 1 ]; then
		log "link switch failed, restoring links"
		restore_links
		write_result failed SWITCH_FAILED "could not switch the current link"
		finish
	fi
	log "current -> $NEW_CURRENT, previous -> $NEW_PREVIOUS"
fi
# Make the links (and the files written so far) durable before the gateway is restarted.
sync

healthy=0
stop_failed=0
# A failed stop may leave the old gateway running; treat it like a failed start.
if ! stop_service; then
	stop_failed=1
elif start_service; then
	log "waiting up to ${HEALTH_TIMEOUT}s for the healthy marker"
	wait_healthy && healthy=1
fi

if [ "$healthy" -eq 1 ]; then
	log "new release is healthy"
	if [ "$MODE" = update ]; then
		write_result "done" "" ""
	else
		write_result reverted "" ""
	fi
	finish prune
fi

log "new release is not healthy, rolling back"
log_journal
stop_service || true
[ "$MODE" = update ] && restore_config
restore_links
sync
if [ "$stop_failed" -eq 1 ]; then
	message="could not stop the gateway service before starting the new release"
else
	message="healthy marker for $TO_VERSION did not appear within ${HEALTH_TIMEOUT}s"
fi
if ! start_service; then
	message="$message; start after rollback failed"
fi
write_result rolledBack HEALTH_CHECK_FAILED "$message"
finish prune
